

function armarInformacion(name,city){
    return `Eres ${name} y votaste el codigo: ${city}`;
}

export {armarInformacion};

